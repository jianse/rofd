use serde::Deserialize;

#[derive(Debug, Deserialize)]
struct Outter {
    #[serde(flatten)]
    base: Inner,

    #[serde(rename = "@ID")]
    id: String,
}
#[derive(Debug, Deserialize)]
struct Inner {
    #[serde(rename = "@Type")]
    r#type: Option<String>,
}

fn main() {
    let res = quick_xml::de::from_str::<Outter>(
        r#"<Outter Type="AAA" DrawParam="4" ID="123">content</Outter>"#,
    );
    let _ = dbg!(res);
}
