use serde::{de::Visitor, Deserialize, Serialize};

use super::base::StRefId;

/// Layer type
// this is not used
#[derive(Debug, Serialize, Deserialize)]
pub struct CtLayer {
    #[serde(rename = "@Type")]
    // #[serde_as(as = "FromInto<String>")]
    r#type: Option<String>,

    #[serde(rename = "@DrawParam")]
    // #[serde_as(as = "FromInto<String>")]
    draw_param: Option<StRefId>,
}

/// deserialize Layer
// impl<'de> Deserialize<'de> for CtLayer {
//     fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
//     where
//         D: serde::Deserializer<'de>,
//     {
//         struct CtLayerVisitor;
//         impl<'de> Visitor<'de> for CtLayerVisitor {
//             type Value = CtLayer;

//             fn expecting(&self, formatter: &mut std::fmt::Formatter) -> std::fmt::Result {
//                 formatter.write_str("data")
//             }
//             fn visit_map<A>(self, map: A) -> Result<Self::Value, A::Error>
//             where
//                 A: serde::de::MapAccess<'de>,
//             {
//                 println!("visit_map!!");
//                 todo!()
//             }
//         }
//         deserializer.deserialize_any(CtLayerVisitor)
//     }
// }
#[derive(Debug, Deserialize)]
struct TestStruct {
    #[serde(flatten)]
    base: CtLayer,
    #[serde(rename = "@ID")]
    id: u64,
    #[serde(rename = "$value")]
    val: String,
}
#[cfg(test)]
mod test_super {
    use super::*;

    #[derive(Debug, Deserialize)]
    struct TestStruct {
        #[serde(flatten)]
        base: CtLayer,
        #[serde(rename = "@ID")]
        id: u64,
        #[serde(rename = "$value")]
        val: String,
    }

    #[test]
    fn test_de_flatten() {
        let res = quick_xml::de::from_str::<TestStruct>(
            r#"<TestStruct Type="AAA" DrawParam="4" ID="123">content</TestStruct>"#,
        );
        let _ = dbg!(res);
    }
}
