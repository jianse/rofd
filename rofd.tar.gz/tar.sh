#!/bin/bash

tar cvzf rofd.tar.gz --exclude=target/**/* --exclude=rofd.tar.gz .